package com.mai.chat.ui.theme

import androidx.compose.ui.graphics.Color

// Minimalist Dark Palette (Gemini/ChatGPT styled)
val DarkBackground = Color(0xFF131314)
val DarkSurface = Color(0xFF1E1F20)
val DarkSurfaceVariant = Color(0xFF282A2C)
val DarkOnBackground = Color(0xFFE3E3E3)
val DarkOnSurface = Color(0xFFE3E3E3)
val DarkOnSurfaceVariant = Color(0xFFC4C7C5)
val DarkPrimary = Color(0xFFA8C7FA)
val DarkOutline = Color(0xFF444746)

// Minimalist Light Palette
val LightBackground = Color(0xFFFFFFFF)
val LightSurface = Color(0xFFF0F4F9)
val LightSurfaceVariant = Color(0xFFE1E3E1)
val LightOnBackground = Color(0xFF1F1F1F)
val LightOnSurface = Color(0xFF1F1F1F)
val LightOnSurfaceVariant = Color(0xFF444746)
val LightPrimary = Color(0xFF0B57D0)
val LightOutline = Color(0xFFC4C7C5)
