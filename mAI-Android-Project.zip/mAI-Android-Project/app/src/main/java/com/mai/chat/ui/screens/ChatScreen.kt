package com.mai.chat.ui.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mai.chat.data.local.MessageEntity
import com.mai.chat.data.local.MessageRole
import com.mai.chat.ui.components.ApiKeyDialog
import com.mai.chat.ui.components.ChatBubble
import com.mai.chat.ui.components.ChatInputField
import com.mai.chat.ui.components.ConversationDrawerContent
import com.mai.chat.ui.components.DirectiveDialog
import com.mai.chat.ui.components.MaiTopAppBar
import com.mai.chat.ui.viewmodel.ChatViewModel
import kotlinx.coroutines.launch

@Composable
fun ChatScreen(viewModel: ChatViewModel) {
    val conversations by viewModel.conversations.collectAsState()
    val activeConversation by viewModel.activeConversation.collectAsState()
    val messages by viewModel.messages.collectAsState()
    val isStreaming by viewModel.isStreaming.collectAsState()
    val streamingChunk by viewModel.streamingChunk.collectAsState()
    val apiKey by viewModel.apiKey.collectAsState()
    val isDarkThemePref by viewModel.isDarkTheme.collectAsState()

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    val snackbarHostState = remember { SnackbarHostState() }

    var showApiKeyDialog by remember { mutableStateOf(false) }
    var showDirectiveDialog by remember { mutableStateOf(false) }
    var inputText by remember { mutableStateOf("") }

    // Auto scroll on new messages
    LaunchedEffect(messages.size, streamingChunk) {
        val totalItems = messages.size + if (streamingChunk.isNotBlank()) 1 else 0
        if (totalItems > 0) {
            listState.animateScrollToItem(totalItems - 1)
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ConversationDrawerContent(
                conversations = conversations,
                activeConversationId = activeConversation?.id,
                onSelectConversation = { convId ->
                    viewModel.selectConversation(convId)
                    coroutineScope.launch { drawerState.close() }
                },
                onNewChat = {
                    viewModel.createNewChat()
                    coroutineScope.launch { drawerState.close() }
                },
                onDeleteConversation = { convId ->
                    viewModel.deleteConversation(convId)
                }
            )
        }
    ) {
        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            topBar = {
                MaiTopAppBar(
                    isDarkTheme = isDarkThemePref ?: true,
                    onMenuClick = {
                        coroutineScope.launch {
                            if (drawerState.isClosed) drawerState.open() else drawerState.close()
                        }
                    },
                    onToggleTheme = {
                        viewModel.toggleTheme()
                    },
                    onApiKeyClick = {
                        showApiKeyDialog = true
                    },
                    onDirectiveClick = {
                        showDirectiveDialog = true
                    },
                    hasApiKey = apiKey.isNotBlank(),
                    hasDirective = activeConversation?.directive?.isNotBlank() == true
                )
            },
            bottomBar = {
                ChatInputField(
                    inputText = inputText,
                    onInputChange = { inputText = it },
                    isLoading = isStreaming,
                    onSend = {
                        if (apiKey.isBlank()) {
                            showApiKeyDialog = true
                            coroutineScope.launch {
                                snackbarHostState.showSnackbar("Please enter your Gemini API key first.")
                            }
                        } else {
                            viewModel.sendMessage(inputText)
                            inputText = ""
                        }
                    }
                )
            }
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                if (messages.isEmpty() && streamingChunk.isBlank()) {
                    // Empty state: Minimal prompt
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Spacer(modifier = Modifier.weight(1f))
                        Text(
                            text = "mAI",
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (activeConversation?.directive?.isNotBlank() == true) {
                                "Directive active: " + activeConversation?.directive?.take(60) + "..."
                            } else {
                                "How can I help you today?"
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.weight(1.2f))
                    }
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(messages, key = { it.id }) { msg ->
                            ChatBubble(message = msg)
                        }

                        // Live streaming message placeholder
                        if (streamingChunk.isNotBlank()) {
                            item(key = "streaming_node") {
                                ChatBubble(
                                    message = MessageEntity(
                                        id = "streaming",
                                        conversationId = activeConversation?.id ?: "",
                                        role = MessageRole.MODEL,
                                        text = streamingChunk
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // API Key Dialog
    if (showApiKeyDialog) {
        ApiKeyDialog(
            currentApiKey = apiKey,
            onDismiss = { showApiKeyDialog = false },
            onSave = { newKey ->
                viewModel.saveApiKey(newKey)
            }
        )
    }

    // Directive Dialog
    if (showDirectiveDialog) {
        DirectiveDialog(
            currentDirective = activeConversation?.directive ?: "",
            onDismiss = { showDirectiveDialog = false },
            onSave = { newDirective ->
                viewModel.saveDirective(newDirective)
            }
        )
    }
}
