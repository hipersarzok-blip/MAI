package com.mai.chat.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Directive dialog providing system instructions and grounding persona
 * for the current conversation thread.
 */
@Composable
fun DirectiveDialog(
    currentDirective: String,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit
) {
    var directiveText by remember { mutableStateOf(currentDirective) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Conversation Directive",
                style = MaterialTheme.typography.titleLarge.copy(fontSize = 18.sp, fontWeight = FontWeight.Bold)
            )
        },
        text = {
            Column {
                Text(
                    text = "Set system instructions for this conversation. The AI will adopt this persona and use it as grounding context with every message.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = directiveText,
                    onValueChange = { directiveText = it },
                    label = { Text("Custom Directives / Persona") },
                    placeholder = { Text("e.g. You are a senior Android Kotlin architect. Provide concise, production-ready code examples.") },
                    minLines = 4,
                    maxLines = 8,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    onSave(directiveText.trim())
                    onDismiss()
                }
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
