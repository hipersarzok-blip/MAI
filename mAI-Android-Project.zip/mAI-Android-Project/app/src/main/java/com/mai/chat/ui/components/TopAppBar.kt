package com.mai.chat.ui.components

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Menu
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.NightlightRound
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Top App Bar meeting exact specification:
 * - Left side: Hamburger menu (≡) to open conversation drawer.
 * - Right side (from right to left):
 *   1. Theme toggle: Sun icon (☀️) in dark mode, Moon icon (🌙) in light mode.
 *   2. API Key button (key icon 🔑): Opens API Key setup dialog.
 *   3. Directive button (document/list icon 📝): Opens directive & persona dialog.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MaiTopAppBar(
    isDarkTheme: Boolean,
    onMenuClick: () -> Unit,
    onToggleTheme: () -> Unit,
    onApiKeyClick: () -> Unit,
    onDirectiveClick: () -> Unit,
    hasApiKey: Boolean,
    hasDirective: Boolean
) {
    TopAppBar(
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.background,
            titleContentColor = MaterialTheme.colorScheme.onBackground
        ),
        navigationIcon = {
            IconButton(onClick = onMenuClick) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Menu,
                    contentDescription = "Open drawer",
                    tint = MaterialTheme.colorScheme.onBackground
                )
            }
        },
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "mAI",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = (-0.5).sp
                    )
                )
            }
        },
        actions = {
            // Directive button (document/list icon 📝)
            IconButton(onClick = onDirectiveClick) {
                Icon(
                    imageVector = Icons.Default.Description,
                    contentDescription = "Conversation Directives",
                    tint = if (hasDirective) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onBackground
                )
            }

            // API Key button (key icon 🔑)
            IconButton(onClick = onApiKeyClick) {
                Icon(
                    imageVector = Icons.Default.Key,
                    contentDescription = "Gemini API Key",
                    tint = if (hasApiKey) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onBackground
                )
            }

            // Theme toggle button: Sun (☀️) in dark mode, Moon (🌙) in light mode
            IconButton(onClick = onToggleTheme) {
                if (isDarkTheme) {
                    Icon(
                        imageVector = Icons.Default.WbSunny,
                        contentDescription = "Switch to Light Mode",
                        tint = MaterialTheme.colorScheme.onBackground
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.NightlightRound,
                        contentDescription = "Switch to Dark Mode",
                        tint = MaterialTheme.colorScheme.onBackground
                    )
                }
            }
        }
    )
}
