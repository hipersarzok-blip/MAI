package com.mai.chat.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mai.chat.data.local.ConversationEntity
import com.mai.chat.data.local.MessageEntity
import com.mai.chat.data.preferences.PreferenceManager
import com.mai.chat.data.repository.ChatRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ChatViewModel(
    private val repository: ChatRepository,
    private val preferenceManager: PreferenceManager
) : ViewModel() {

    val conversations: StateFlow<List<ConversationEntity>> = repository.allConversations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val apiKey: StateFlow<String> = preferenceManager.apiKeyFlow
    val isDarkTheme: StateFlow<Boolean?> = preferenceManager.isDarkThemeFlow

    private val _activeConversation = MutableStateFlow<ConversationEntity?>(null)
    val activeConversation: StateFlow<ConversationEntity?> = _activeConversation.asStateFlow()

    private val _messages = MutableStateFlow<List<MessageEntity>>(emptyList())
    val messages: StateFlow<List<MessageEntity>> = _messages.asStateFlow()

    private val _isStreaming = MutableStateFlow(false)
    val isStreaming: StateFlow<Boolean> = _isStreaming.asStateFlow()

    private val _streamingChunk = MutableStateFlow("")
    val streamingChunk: StateFlow<String> = _streamingChunk.asStateFlow()

    private var messagesJob: Job? = null
    private var streamingJob: Job? = null

    init {
        viewModelScope.launch {
            // Observe conversations and pick initial active conversation or create first one
            conversations.collect { list ->
                if (_activeConversation.value == null) {
                    if (list.isNotEmpty()) {
                        selectConversation(list.first().id)
                    } else {
                        createNewChat()
                    }
                }
            }
        }
    }

    fun selectConversation(conversationId: String) {
        viewModelScope.launch {
            val conv = conversations.value.find { it.id == conversationId }
            _activeConversation.value = conv

            messagesJob?.cancel()
            messagesJob = viewModelScope.launch {
                repository.getMessagesForConversation(conversationId).collect { msgs ->
                    _messages.value = msgs
                }
            }
        }
    }

    fun createNewChat(directive: String = "") {
        viewModelScope.launch {
            val newConv = repository.createNewConversation(directive)
            selectConversation(newConv.id)
        }
    }

    fun saveDirective(newDirective: String) {
        val currentConv = _activeConversation.value ?: return
        viewModelScope.launch {
            repository.updateDirective(currentConv.id, newDirective)
            _activeConversation.value = currentConv.copy(directive = newDirective)
        }
    }

    fun deleteConversation(conversationId: String) {
        viewModelScope.launch {
            repository.deleteConversation(conversationId)
            if (_activeConversation.value?.id == conversationId) {
                _activeConversation.value = null
            }
        }
    }

    fun saveApiKey(newKey: String) {
        preferenceManager.saveApiKey(newKey)
    }

    fun toggleTheme() {
        val current = isDarkTheme.value ?: true
        preferenceManager.saveDarkTheme(!current)
    }

    fun sendMessage(text: String) {
        val conv = _activeConversation.value ?: return
        if (text.isBlank()) return

        viewModelScope.launch {
            // Save user message to Room
            repository.insertUserMessage(conv.id, text)

            _isStreaming.value = true
            _streamingChunk.value = ""

            val fullResponseBuilder = StringBuilder()

            streamingJob?.cancel()
            streamingJob = viewModelScope.launch {
                repository.streamGeminiResponse(
                    conversationId = conv.id,
                    prompt = text,
                    directive = conv.directive
                ).catch { error ->
                    _isStreaming.value = false
                    val errorMsg = "Error: " + (error.message ?: "Failed to generate response")
                    repository.insertAiMessage(conv.id, errorMsg)
                    _streamingChunk.value = ""
                }.collect { chunk ->
                    fullResponseBuilder.append(chunk)
                    _streamingChunk.value = fullResponseBuilder.toString()
                }

                // Streaming finished, commit full message to Room
                if (fullResponseBuilder.isNotEmpty()) {
                    repository.insertAiMessage(conv.id, fullResponseBuilder.toString())
                }
                _isStreaming.value = false
                _streamingChunk.value = ""
            }
        }
    }
}
