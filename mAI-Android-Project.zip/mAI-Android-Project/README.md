# mAI - Minimalist AI Chat Client (Android)

A minimalist native Android client for Google Gemini built with Kotlin and Jetpack Compose.

## Features
- **Minimalist Top Bar**:
  - Hamburger Drawer (≡) for conversation management
  - Directive Button (📝) for custom system instructions and persona grounding
  - API Key Button (🔑) for runtime secure key management
  - Theme Toggle (☀️ Sun in dark mode / 🌙 Moon in light mode)
- **Model**: Google Gemini 2.5 Flash (`gemini-2.5-flash`)
- **Persistence**: Room Database (Conversations & Messages)
- **Security**: EncryptedSharedPreferences for API key storage
- **Clean Architecture**: Repository pattern + ViewModel + StateFlow

## How to Build in Android Studio
1. Open Android Studio (Hedgehog, Iguana, Koala, Ladybug or newer).
2. Select **File > Open...** and select this directory (`mAI-Android-Project`).
3. Allow Gradle to sync.
4. Run on an Android Device or Emulator running Android 8.0+ (API 26+).
5. Tap the **🔑** icon in the top right to input your Gemini API Key and start chatting!
